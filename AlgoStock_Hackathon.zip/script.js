// ==========================================
// MOCK DATABASE & INITIALIZATION
// ==========================================
const INITIAL_PRODUCTS = [
    { id: 1, name: "Wireless Mouse", category: "Electronics", quantity: 15, reorder_level: 20, max_stock_level: 100, supplier_name: "TechSupplier Inc", price: 25.99 },
    { id: 2, name: "Mechanical Keyboard", category: "Electronics", quantity: 45, reorder_level: 10, max_stock_level: 50, supplier_name: "TechSupplier Inc", price: 89.99 },
    { id: 3, name: "USB-C Cable", category: "Accessories", quantity: 150, reorder_level: 50, max_stock_level: 200, supplier_name: "ConnectAll", price: 12.50 },
    { id: 4, name: "Ergonomic Chair", category: "Furniture", quantity: 2, reorder_level: 5, max_stock_level: 20, supplier_name: "OfficeComfort", price: 199.99 },
    { id: 5, name: "Laptop Stand", category: "Accessories", quantity: 0, reorder_level: 10, max_stock_level: 40, supplier_name: "OfficeComfort", price: 35.00 },
    { id: 6, name: "Bluetooth Speaker", category: "Electronics", quantity: 85, reorder_level: 15, max_stock_level: 60, supplier_name: "AudioPhile", price: 45.00 },
    { id: 7, name: "Webcam 1080p", category: "Electronics", quantity: 8, reorder_level: 10, max_stock_level: 30, supplier_name: "TechSupplier Inc", price: 55.00 },
    { id: 8, name: "Desk Lamp", category: "Furniture", quantity: 110, reorder_level: 15, max_stock_level: 50, supplier_name: "BrightLight", price: 22.00 }
];

const INITIAL_SALES = {
    1: 45, 2: 12, 3: 200, 4: 5, 5: 30, 6: 15, 7: 8, 8: 10 // units sold last 30 days
};

function initDB() {
    if (!localStorage.getItem('algo_products')) {
        localStorage.setItem('algo_products', JSON.stringify(INITIAL_PRODUCTS));
    }
    if (!localStorage.getItem('algo_sales')) {
        localStorage.setItem('algo_sales', JSON.stringify(INITIAL_SALES));
    }
}
initDB();

function getProducts() {
    return JSON.parse(localStorage.getItem('algo_products'));
}
function saveProducts(products) {
    localStorage.setItem('algo_products', JSON.stringify(products));
}
function getSales() {
    return JSON.parse(localStorage.getItem('algo_sales'));
}

// Global State
let inventoryData = [];
let charts = {};

// DOM Elements
const loginView = document.getElementById('login-view');
const appShell = document.getElementById('app-shell');
const loginForm = document.getElementById('login-form');
const loginError = document.getElementById('login-error');
const navLinks = document.querySelectorAll('.nav-link');
const contentViews = document.querySelectorAll('.content-view');

// ==========================================
// APP LOGIC
// ==========================================

// Login Flow
loginForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    
    if (username === 'admin' && password === 'admin123') {
        loginView.classList.remove('active');
        setTimeout(() => {
            loginView.classList.add('hidden');
            appShell.classList.remove('hidden');
            initApp();
        }, 300);
    } else {
        loginError.textContent = "Invalid credentials. Use admin / admin123";
        loginError.classList.remove('hidden');
    }
});

document.getElementById('logout-btn').addEventListener('click', () => {
    appShell.classList.add('hidden');
    loginView.classList.remove('hidden');
    setTimeout(() => loginView.classList.add('active'), 50);
});

// View Routing (SPA Logic)
navLinks.forEach(link => {
    link.addEventListener('click', (e) => {
        e.preventDefault();
        const targetId = link.getAttribute('data-target');
        
        navLinks.forEach(n => n.classList.remove('active'));
        link.classList.add('active');
        
        contentViews.forEach(v => v.classList.remove('active'));
        document.getElementById(targetId).classList.add('active');
        
        if (targetId === 'dashboard-view') fetchDashboardStats();
        if (targetId === 'inventory-view') fetchInventory();
        if (targetId === 'alerts-view') fetchAlerts();
        if (targetId === 'sales-view') fetchSales();
        if (targetId === 'optimization-view') fetchOptimizations();
    });
});

document.getElementById('get-started-btn').addEventListener('click', () => {
    document.querySelector('[data-target="dashboard-view"]').click();
});

function initApp() {
    Chart.defaults.color = '#9ca3af';
    Chart.defaults.borderColor = '#262626';
    setupCharts();
    fetchDashboardStats();
    fetchInventory();
    checkAlertBadge();
}

// ---------------- Data Processing Functions ---------------- //

function fetchDashboardStats() {
    const products = getProducts();
    const totalProducts = products.length;
    let lowStock = 0, outOfStock = 0, overstocked = 0;
    
    products.forEach(p => {
        if (p.quantity === 0) outOfStock++;
        else if (p.quantity <= p.reorder_level) lowStock++;
        else if (p.quantity > p.max_stock_level) overstocked++;
    });
    
    document.getElementById('kpi-total').textContent = totalProducts;
    document.getElementById('kpi-low').textContent = lowStock;
    document.getElementById('kpi-out').textContent = outOfStock;
    document.getElementById('kpi-over').textContent = overstocked;
    
    updateInventoryChart({ totalProducts, lowStock, outOfStock, overstocked });
}

document.getElementById('refresh-dashboard').addEventListener('click', fetchDashboardStats);

document.getElementById('run-optimization').addEventListener('click', () => {
    const flash = document.getElementById('optimization-flash');
    flash.classList.remove('hidden');
    setTimeout(() => {
        fetchDashboardStats();
        checkAlertBadge();
        flash.classList.add('hidden');
        alert("Real-time optimization check complete.");
    }, 1000);
});

function fetchInventory() {
    const products = getProducts();
    const sales = getSales();
    const total_value = products.reduce((sum, p) => sum + (p.quantity * p.price), 0);
    
    inventoryData = products.map(item => {
        // Velocity calculation
        const soldLast30 = sales[item.id] || 0;
        const velocity = soldLast30 / 30.0;
        if (velocity > 0) {
            item.stockout_eta = Math.floor(item.quantity / velocity) + " days";
        } else {
            item.stockout_eta = "No Data";
        }
        
        // ABC Class
        const value = item.quantity * item.price;
        if (total_value > 0) {
            const pct = value / total_value;
            if (pct > 0.3) item.abc_class = 'A';
            else if (pct > 0.05) item.abc_class = 'B';
            else item.abc_class = 'C';
        } else {
            item.abc_class = 'C';
        }
        return item;
    });
    
    renderInventoryTable();
}

function renderInventoryTable() {
    const tbody = document.querySelector('#inventory-table tbody');
    tbody.innerHTML = '';
    
    inventoryData.forEach(item => {
        const row = document.createElement('tr');
        if (item.quantity == 0) row.style.color = 'var(--danger)';
        else if (item.quantity <= item.reorder_level) row.style.color = 'var(--warning)';
        
        row.innerHTML = `
            <td>#${item.id}</td>
            <td>${item.name}</td>
            <td>${item.category}</td>
            <td><strong>${item.abc_class || 'C'}</strong></td>
            <td><strong>${item.quantity}</strong></td>
            <td>${item.stockout_eta || 'No Data'}</td>
            <td>${item.reorder_level}</td>
            <td>${item.max_stock_level}</td>
            <td>₹${parseFloat(item.price).toFixed(2)}</td>
            <td>
                <button class="btn outline-btn" onclick="openEditModal(${item.id})" style="padding: 5px 10px; font-size: 12px;">Edit</button>
            </td>
        `;
        tbody.appendChild(row);
    });
}

function fetchAlerts() {
    const products = getProducts();
    const container = document.getElementById('alerts-container');
    container.innerHTML = '';
    
    let alertsCount = 0;
    products.forEach(p => {
        let type, message;
        if (p.quantity === 0) {
            type = 'critical'; message = `${p.name} is OUT OF STOCK. Immediate reorder required.`;
        } else if (p.quantity <= p.reorder_level) {
            type = 'warning'; message = `${p.name} is LOW ON STOCK (${p.quantity} left). Reorder level: ${p.reorder_level}.`;
        } else if (p.quantity > p.max_stock_level) {
            type = 'info'; message = `${p.name} is OVERSTOCKED (${p.quantity} units). Consider discounting.`;
        } else {
            return; // no alert
        }
        
        alertsCount++;
        const div = document.createElement('div');
        div.className = `alert-item ${type}`;
        div.innerHTML = `
            <div>
                <strong>${type.toUpperCase()}:</strong> ${message}
            </div>
            <button class="btn primary resolve-btn" style="padding: 6px 12px; font-size: 12px;">Resolve</button>
        `;
        div.querySelector('.resolve-btn').addEventListener('click', () => {
            div.style.display = 'none';
        });
        container.appendChild(div);
    });
    
    if (alertsCount === 0) {
        container.innerHTML = '<p style="color: var(--text-muted)">All stock levels are optimal. No alerts.</p>';
    }
}

function checkAlertBadge() {
    const products = getProducts();
    const hasAlerts = products.some(p => p.quantity <= p.reorder_level || p.quantity > p.max_stock_level);
    const badge = document.getElementById('alert-badge');
    if (hasAlerts) badge.classList.remove('hidden');
    else badge.classList.add('hidden');
}

document.getElementById('generate-alerts-btn').addEventListener('click', fetchAlerts);

function fetchSales() {
    // Generate some mock historical chart data in browser
    const dates = [];
    const daily = [];
    for(let i=14; i>=0; i--) {
        const d = new Date();
        d.setDate(d.getDate() - i);
        dates.push(d.toLocaleDateString('en-US', {month:'short', day:'numeric'}));
        daily.push(Math.floor(Math.random() * 20) + 5);
    }
    
    charts.sales.data.labels = dates;
    charts.sales.data.datasets[0].data = daily;
    charts.sales.update();
    
    const products = getProducts();
    const sales = getSales();
    const sorted = [...products].sort((a,b) => (sales[b.id]||0) - (sales[a.id]||0)).slice(0,5);
    
    charts.bestSellers.data.labels = sorted.map(p => p.name);
    charts.bestSellers.data.datasets[0].data = sorted.map(p => sales[p.id]||0);
    charts.bestSellers.update();
}

function fetchOptimizations() {
    const products = getProducts();
    const container = document.getElementById('suggestions-container');
    container.innerHTML = '';
    
    let suggCount = 0;
    products.forEach(p => {
        let action, details;
        if (p.quantity <= p.reorder_level && p.quantity > 0) {
            action = "Reorder"; details = `Stock is at ${p.quantity}. Reorder ${p.max_stock_level - p.quantity} units.`;
        } else if (p.quantity === 0) {
            action = "Urgent Reorder"; details = `Out of stock! Order ${p.max_stock_level} units immediately.`;
        } else if (p.quantity > p.max_stock_level) {
            action = "Reduce Stock"; details = `Overstocked by ${p.quantity - p.max_stock_level} units. Suggest a 15% markdown.`;
        } else {
            return;
        }
        
        suggCount++;
        const div = document.createElement('div');
        div.className = 'suggestion-item';
        const isReorder = action.includes('Reorder');
        const btnText = isReorder ? '1-Click Auto-Order' : 'Apply Action';
        
        div.innerHTML = `
            <div class="suggestion-content">
                <strong>${action} - ${p.name}</strong>
                <p>${details}</p>
            </div>
            <button class="btn primary apply-action-btn">${btnText}</button>
        `;
        div.querySelector('.apply-action-btn').addEventListener('click', () => {
            if(isReorder) alert(`Drafting email to supplier for ${p.name}... Done!`);
            else alert(`Action applied: ${action} for ${p.name}`);
            div.style.display = 'none';
        });
        container.appendChild(div);
    });
    
    if (suggCount === 0) {
        container.innerHTML = '<p style="color: var(--text-muted)">Inventory is perfectly optimized.</p>';
    }
}

document.getElementById('generate-suggestions-btn').addEventListener('click', fetchOptimizations);

// ---------------- Chart Setup ---------------- //

function setupCharts() {
    const invCtx = document.getElementById('inventoryChart').getContext('2d');
    charts.inventory = new Chart(invCtx, {
        type: 'doughnut',
        data: {
            labels: ['Healthy Stock', 'Low Stock', 'Out of Stock', 'Overstocked'],
            datasets: [{
                data: [0, 0, 0, 0],
                backgroundColor: ['#10b981', '#f59e0b', '#ef4444', '#3b82f6'],
                borderWidth: 0
            }]
        },
        options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'right' } } }
    });

    const salesCtx = document.getElementById('salesChart').getContext('2d');
    charts.sales = new Chart(salesCtx, {
        type: 'line',
        data: {
            labels: [],
            datasets: [{
                label: 'Daily Units Sold',
                data: [],
                borderColor: '#facc15',
                backgroundColor: 'rgba(250, 204, 21, 0.1)',
                fill: true,
                tension: 0.4
            }]
        },
        options: { responsive: true, maintainAspectRatio: false }
    });
    
    const bestCtx = document.getElementById('bestSellersChart').getContext('2d');
    charts.bestSellers = new Chart(bestCtx, {
        type: 'bar',
        data: {
            labels: [],
            datasets: [{
                label: 'Total Units Sold',
                data: [],
                backgroundColor: '#facc15',
                borderRadius: 4
            }]
        },
        options: { responsive: true, maintainAspectRatio: false }
    });
}

function updateInventoryChart(data) {
    const healthy = data.totalProducts - (data.lowStock + data.outOfStock + data.overstocked);
    charts.inventory.data.datasets[0].data = [healthy, data.lowStock, data.outOfStock, data.overstocked];
    charts.inventory.update();
}

// ---------------- Modal Logic ---------------- //
const addProductModal = document.getElementById('add-product-modal');
document.getElementById('add-product-btn').addEventListener('click', () => {
    addProductModal.classList.remove('hidden');
});
document.getElementById('close-modal-btn').addEventListener('click', () => {
    addProductModal.classList.add('hidden');
});
document.getElementById('add-product-form').addEventListener('submit', (e) => {
    e.preventDefault();
    const products = getProducts();
    const newId = products.length > 0 ? Math.max(...products.map(p=>p.id)) + 1 : 1;
    
    const newProduct = {
        id: newId,
        name: document.getElementById('prod-name').value,
        category: document.getElementById('prod-category').value,
        quantity: parseInt(document.getElementById('prod-quantity').value),
        price: parseFloat(document.getElementById('prod-price').value),
        reorder_level: parseInt(document.getElementById('prod-reorder').value),
        max_stock_level: parseInt(document.getElementById('prod-max').value),
        supplier_name: document.getElementById('prod-supplier').value || 'Unknown'
    };
    
    products.push(newProduct);
    saveProducts(products);
    
    addProductModal.classList.add('hidden');
    document.getElementById('add-product-form').reset();
    fetchInventory();
    fetchDashboardStats();
    alert("Product added successfully!");
});

// Edit Product Logic
const editProductModal = document.getElementById('edit-product-modal');

window.openEditModal = function(id) {
    const item = inventoryData.find(i => i.id === id);
    if (!item) return;
    
    document.getElementById('edit-prod-id').value = item.id;
    document.getElementById('edit-prod-name').value = item.name;
    document.getElementById('edit-prod-category').value = item.category;
    document.getElementById('edit-prod-quantity').value = item.quantity;
    document.getElementById('edit-prod-price').value = item.price;
    document.getElementById('edit-prod-reorder').value = item.reorder_level;
    document.getElementById('edit-prod-max').value = item.max_stock_level;
    document.getElementById('edit-prod-supplier').value = item.supplier_name;
    
    editProductModal.classList.remove('hidden');
};

document.getElementById('close-edit-modal-btn').addEventListener('click', () => {
    editProductModal.classList.add('hidden');
});

document.getElementById('edit-product-form').addEventListener('submit', (e) => {
    e.preventDefault();
    const id = parseInt(document.getElementById('edit-prod-id').value);
    const products = getProducts();
    const idx = products.findIndex(p => p.id === id);
    
    if (idx !== -1) {
        products[idx] = {
            id: id,
            name: document.getElementById('edit-prod-name').value,
            category: document.getElementById('edit-prod-category').value,
            quantity: parseInt(document.getElementById('edit-prod-quantity').value),
            price: parseFloat(document.getElementById('edit-prod-price').value),
            reorder_level: parseInt(document.getElementById('edit-prod-reorder').value),
            max_stock_level: parseInt(document.getElementById('edit-prod-max').value),
            supplier_name: document.getElementById('edit-prod-supplier').value
        };
        saveProducts(products);
        
        editProductModal.classList.add('hidden');
        fetchInventory();
        fetchDashboardStats();
        alert("Product updated successfully!");
    }
});
